$dest="$PSScriptRoot/evidence"
New-Item -ItemType Directory -Path "$dest/screenshots","$dest/observations","$dest/reproduction","$dest/regressions","$dest/application/data" -Force | Out-Null
$images=Get-ChildItem $PSScriptRoot -File | Where-Object { $_.Name -match '^(720-|1080-(100|125)-|settings-(720-disabled|1080-100|1080-125|restored)).*\.png$' }
foreach($f in $images){Copy-Item -LiteralPath $f.FullName -Destination "$dest/screenshots"}
$records=Get-ChildItem $PSScriptRoot -File | Where-Object { $_.Name -match '^(720-|1080-(100|125)-|settings-(1080-100|1080-125|restored)|restored-|original-taskbar|artifact-hashes|actions)' -and $_.Extension -ne '.png' }
foreach($f in $records){Copy-Item -LiteralPath $f.FullName -Destination "$dest/observations"}
Copy-Item -LiteralPath "$PSScriptRoot/original-fixture.json" -Destination "$dest/application/data/ponhub.json"
Copy-Item -LiteralPath "$PSScriptRoot/run/ponhub.jar" -Destination "$dest/application/ponhub.jar"
Copy-Item -LiteralPath "$PSScriptRoot/run/preferences.json" -Destination "$dest/application/preferences.json"
Copy-Item -LiteralPath "$PSScriptRoot/round3-acceptance-report.txt" -Destination $dest
if(Test-Path "$PSScriptRoot/round3-exact-acceptance-report.txt"){Copy-Item -LiteralPath "$PSScriptRoot/round3-exact-acceptance-report.txt" -Destination $dest}
if(Test-Path "$PSScriptRoot/force-150"){
 New-Item -ItemType Directory -Path "$dest/exact-setup" -Force | Out-Null
 Get-ChildItem "$PSScriptRoot/force-150" -File | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination "$dest/exact-setup"}
}
Get-ChildItem $PSScriptRoot -File | Where-Object { $_.Extension -eq '.ps1' -or $_.Extension -eq '.java' } | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination "$dest/reproduction"}
Get-ChildItem "$PSScriptRoot/../../build/test-results/test" -Filter 'TEST-*.xml' | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination "$dest/regressions"}
$files=Get-ChildItem $dest -Recurse -File | Where-Object {$_.Name -ne 'evidence-manifest.csv'}
$files | ForEach-Object { [PSCustomObject]@{path=$_.FullName.Substring($dest.Length+1);bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLower()} } | Export-Csv "$dest/evidence-manifest.csv" -NoTypeInformation
Compress-Archive -Path "$dest/*" -DestinationPath "$PSScriptRoot/round3-windows-evidence.zip" -Force
Get-FileHash "$PSScriptRoot/round3-windows-evidence.zip"
Get-Item "$PSScriptRoot/round3-windows-evidence.zip" | Select-Object Length
"Screenshot count: $($images.Count)"
