param([string]$Prefix)
. "$PSScriptRoot/ui.ps1"
Exit-PonHub
@{guiSettings=@{windowWidth=5000;windowHeight=5000;windowCoordinates=@{x=50;y=50}}} | ConvertTo-Json -Depth 4 | Set-Content "$PSScriptRoot/run/preferences.json"
Start-PonHub
Save-Window PonHub "$Prefix-oversized-recovered.png"
$screen=[Windows.Forms.Screen]::PrimaryScreen.Bounds
Save-Region 0 0 $screen.Width $screen.Height "$Prefix-oversized-taskbar.png"
Exit-PonHub
Copy-Item "$PSScriptRoot/run/preferences.json" "$PSScriptRoot/$Prefix-oversized-preferences.json"
Copy-Item "$PSScriptRoot/run/stderr.txt" "$PSScriptRoot/$Prefix-oversized.log"
@{guiSettings=@{windowWidth=740;windowHeight=600;windowCoordinates=@{x=99999;y=99999}}} | ConvertTo-Json -Depth 4 | Set-Content "$PSScriptRoot/run/preferences.json"
Start-PonHub
Save-Window PonHub "$Prefix-offscreen-recovered.png"
Exit-PonHub
Copy-Item "$PSScriptRoot/run/preferences.json" "$PSScriptRoot/$Prefix-offscreen-preferences.json"
Copy-Item "$PSScriptRoot/run/stderr.txt" "$PSScriptRoot/$Prefix-offscreen.log"
