$run = "$PSScriptRoot/run"
New-Item -ItemType Directory -Path "$run/data" -Force | Out-Null
Copy-Item -LiteralPath "$PSScriptRoot/../../build/libs/ponhub.jar" -Destination "$run/ponhub.jar"
$people = @()
for ($i=1;$i -le 6;$i++) {
 $word=@('One','Two','Three','Four','Five','Six')[$i-1]
 $people += [ordered]@{ id="S$($i*5+2)";role='STUDENT';name="Student Number $word";level='P2';parentPhone='00987654' }
 $people += [ordered]@{ id="T$($i*5+2)";role='TUTOR';name="Tutor Number $word";phone='000123456789012' }
 $people += [ordered]@{ id="P$($i*5+2)";role='PARENT';name="Parent Number $word";phone='00987654' }
}
$people[4].name='Alexandria ' * 8 + 'NameEnd'
$people[4].email='longcontact' * 20 + 'emailend@example.com'
$people[4].address='12 ' + 'A long residential road ' * 6 + 'AddressEnd Singapore 123456'
$people += [ordered]@{id='P44';role='PARENT';name='Final Parent';phone='000987654';address='Final Contact AddressEnd'}
$fixture=[ordered]@{schemaVersion=1;people=$people;personCounters=@{STUDENT=40;TUTOR=70;PARENT=50};lastAllocatedLessonSequence=0;lessons=@();attendance=@()}
$fixture | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8NoBOM "$run/data/ponhub.json"
Copy-Item "$run/data/ponhub.json" "$PSScriptRoot/original-fixture.json"
@{guiSettings=@{windowWidth=450;windowHeight=360;windowCoordinates=@{x=50;y=50}}} | ConvertTo-Json -Depth 4 | Set-Content "$run/preferences.json"
Get-FileHash "$run/data/ponhub.json","$run/ponhub.jar" | ConvertTo-Json | Set-Content "$PSScriptRoot/artifact-hashes.json"
