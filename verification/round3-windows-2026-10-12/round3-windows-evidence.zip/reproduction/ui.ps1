Add-Type -AssemblyName System.Windows.Forms,System.Drawing,UIAutomationClient,UIAutomationTypes
Add-Type @'
using System;
using System.Runtime.InteropServices;
public class NativeUi {
 public delegate bool Callback(IntPtr w,IntPtr p);
 [DllImport("user32.dll")] public static extern bool EnumWindows(Callback c,IntPtr p);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr w,out uint pid);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr w,System.Text.StringBuilder t,int n);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string cls,string title);
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int left,top,right,bottom;}
 [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr w);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern void keybd_event(byte key,byte scan,uint flags,UIntPtr extra);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr w,int c);
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr w,out RECT r);
 [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr w);
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,int data,UIntPtr info);
}
'@
[NativeUi]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null
[NativeUi]::SetThreadDpiAwarenessContext([IntPtr](-4)) | Out-Null
function Get-AppWindow([string]$name) {
 $p=Get-Process | Where-Object { $_.MainWindowTitle -eq $name } | Select-Object -First 1
 if (!$p) { throw "Window unavailable: $name" }; return $p
}
function Start-PonHub {
 $run="$PSScriptRoot/run"
 $p=Start-Process -FilePath 'C:/Program Files/Java/jdk-25.0.4/bin/java.exe' -ArgumentList '-jar','ponhub.jar' -WorkingDirectory $run -WindowStyle Hidden -PassThru -RedirectStandardOutput "$run/stdout.txt" -RedirectStandardError "$run/stderr.txt"
 $p.Id | Set-Content "$PSScriptRoot/app-pid.txt"
 Start-Sleep -Seconds 2
 [NativeUi]::EnumWindows({param($w,$v)
  $ownerPid=0; [NativeUi]::GetWindowThreadProcessId($w,[ref]$ownerPid)|Out-Null
  if($ownerPid -eq $p.Id) {
   $buf=New-Object Text.StringBuilder 256; [NativeUi]::GetWindowText($w,$buf,256)|Out-Null
   if($buf.ToString() -eq 'PonHub') { [NativeUi]::ShowWindow($w,9)|Out-Null; [NativeUi]::SetForegroundWindow($w)|Out-Null }
  }; return $true
 },[IntPtr]::Zero)|Out-Null
 Start-Sleep -Milliseconds 500
}
function Save-Window([string]$name,[string]$file) {
 $p=Get-AppWindow $name
 [NativeUi]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
 if([NativeUi]::GetForegroundWindow() -ne $p.MainWindowHandle) {
  [NativeUi]::keybd_event(18,0,0,[UIntPtr]::Zero)
  [NativeUi]::SetForegroundWindow($p.MainWindowHandle)|Out-Null
  [NativeUi]::keybd_event(18,0,2,[UIntPtr]::Zero)
 }
 if([NativeUi]::GetForegroundWindow() -ne $p.MainWindowHandle){throw "Window did not become foreground: $name; screenshot cancelled"}
 Start-Sleep -Milliseconds 500
 $r=New-Object NativeUi+RECT
 [NativeUi]::GetWindowRect($p.MainWindowHandle,[ref]$r) | Out-Null
 $img=New-Object Drawing.Bitmap ($r.right-$r.left),($r.bottom-$r.top)
 $g=[Drawing.Graphics]::FromImage($img)
 $g.CopyFromScreen($r.left,$r.top,0,0,$img.Size)
 $img.Save("$PSScriptRoot/$file")
 $g.Dispose(); $img.Dispose()
 $meta=[ordered]@{title=$name;pid=$p.Id;dpi=[NativeUi]::GetDpiForWindow($p.MainWindowHandle);rect=$r}
 $meta | ConvertTo-Json -Depth 3 | Set-Content "$PSScriptRoot/$file.json"
 Get-AppTree $name | Set-Content "$PSScriptRoot/$file.tree.jsonl"
 $meta | ConvertTo-Json -Depth 3
}
function Get-AppTree([string]$name) {
 $p=Get-AppWindow $name
 $root=[Windows.Automation.AutomationElement]::FromHandle($p.MainWindowHandle)
 $nodes=$root.FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
 foreach($node in $nodes) { $v=$node.Current; if (!$v.IsOffscreen) { [ordered]@{name=$v.Name;id=$v.AutomationId;type=$v.ControlType.ProgrammaticName;enabled=$v.IsEnabled;rect=$v.BoundingRectangle.ToString()} | ConvertTo-Json -Compress } }
}
function Save-Region([int]$x,[int]$y,[int]$width,[int]$height,[string]$file) {
 $img=New-Object Drawing.Bitmap $width,$height
 $g=[Drawing.Graphics]::FromImage($img)
 $g.CopyFromScreen($x,$y,0,0,$img.Size)
 $img.Save("$PSScriptRoot/$file"); $g.Dispose(); $img.Dispose()
}
function Drag-Point([int]$x,[int]$y,[int]$endX,[int]$endY) {
 "$(Get-Date -Format o) drag $x,$y -> $endX,$endY" | Add-Content "$PSScriptRoot/actions.log"
 [NativeUi]::SetCursorPos($x,$y) | Out-Null
 [NativeUi]::mouse_event(2,0,0,0,[UIntPtr]::Zero)
 for($i=1;$i -le 20;$i++) { [NativeUi]::SetCursorPos(($x+($endX-$x)*$i/20),($y+($endY-$y)*$i/20))|Out-Null; Start-Sleep -Milliseconds 20 }
 [NativeUi]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 300
}
function Wheel-Point([int]$x,[int]$y,[int]$delta,[int]$count=1) {
 "$(Get-Date -Format o) wheel $x,$y delta=$delta count=$count" | Add-Content "$PSScriptRoot/actions.log"
 [NativeUi]::SetCursorPos($x,$y)|Out-Null
 for($i=0;$i -lt $count;$i++) { [NativeUi]::mouse_event(0x800,0,0,$delta,[UIntPtr]::Zero); Start-Sleep -Milliseconds 60 }
 Start-Sleep -Milliseconds 250
}
function Click-Point([int]$x,[int]$y) {
 "$(Get-Date -Format o) click $x,$y" | Add-Content "$PSScriptRoot/actions.log"
 [NativeUi]::SetCursorPos($x,$y)|Out-Null
 [NativeUi]::mouse_event(2,0,0,0,[UIntPtr]::Zero)
 [NativeUi]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 200
}
function Send-AppKeys([string]$name,[string]$keys) {
 "$(Get-Date -Format o) keys $name $keys" | Add-Content "$PSScriptRoot/actions.log"
 $p=Get-AppWindow $name
 [NativeUi]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
 [Windows.Forms.SendKeys]::SendWait($keys)
 Start-Sleep -Milliseconds 300
}
function Find-Setting([string]$id) {
 $p=Get-AppWindow Settings
 $root=[Windows.Automation.AutomationElement]::FromHandle($p.MainWindowHandle)
 $cond=New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::AutomationIdProperty),$id
 $n=$root.FindFirst([Windows.Automation.TreeScope]::Descendants,$cond)
 if (!$n) {throw "Setting missing: $id"}; return $n
}
function Select-Setting([string]$id,[string]$label) {
 $n=Find-Setting $id
 $n.SetFocus()
 $exp=$n.GetCurrentPattern([Windows.Automation.ExpandCollapsePattern]::Pattern)
 $exp.Expand(); Start-Sleep -Milliseconds 300
 $p=Get-AppWindow Settings
 $root=[Windows.Automation.AutomationElement]::FromHandle($p.MainWindowHandle)
 $cond=New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::NameProperty),$label
 $item=$root.FindAll([Windows.Automation.TreeScope]::Descendants,$cond) | Select-Object -First 1
 if (!$item) {throw "Option missing: $label"}
 if ($item.Current.IsOffscreen) { $item.GetCurrentPattern([Windows.Automation.ScrollItemPattern]::Pattern).ScrollIntoView() }
 $item.GetCurrentPattern([Windows.Automation.SelectionItemPattern]::Pattern).Select()
 Start-Sleep -Milliseconds 700
}
function Save-SettingsEvidence([string]$file) {
 $p=Get-AppWindow Settings
 [NativeUi]::SetForegroundWindow($p.MainWindowHandle)|Out-Null
 Start-Sleep -Milliseconds 300
 $root=[Windows.Automation.AutomationElement]::FromHandle($p.MainWindowHandle)
 $cond=New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::NameProperty),'Scale & layout'
 $n=$root.FindAll([Windows.Automation.TreeScope]::Descendants,$cond) | Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::Group} | Select-Object -First 1
 $r=$n.Current.BoundingRectangle
 $screen=[Windows.Forms.Screen]::PrimaryScreen.Bounds
 $height=[Math]::Min($r.Height,$screen.Height-$r.Y)
 Save-Region $r.X $r.Y $r.Width $height $file
 Get-AppTree Settings | Where-Object { $_ -match 'Scale|%|resolution|1920|1280|ComboBox' } | Set-Content "$PSScriptRoot/$file.tree.jsonl"
}
function Exit-PonHub {
 $p=Get-AppWindow PonHub; $r=New-Object NativeUi+RECT
 [NativeUi]::GetWindowRect($p.MainWindowHandle,[ref]$r)|Out-Null
 $scale=[NativeUi]::GetDpiForWindow($p.MainWindowHandle)/96.0
 Click-Point ($r.left+150*$scale) ($r.top+90*$scale)
 Send-AppKeys PonHub '^aexit{ENTER}'
 Start-Sleep -Milliseconds 500
 if(Get-Process -Id $p.Id -ErrorAction SilentlyContinue) { throw 'Typed Exit did not end process' }
}
