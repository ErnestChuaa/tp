import javafx.application.Platform;
import javafx.stage.Screen;
public class ScreenMetrics {
 public static void main(String[] args) {
  Platform.startup(() -> Platform.runLater(() -> {
   for (Screen s: Screen.getScreens()) System.out.println("bounds="+s.getBounds()+" visual="+s.getVisualBounds()+" dpi="+s.getDpi()+" outputScale="+s.getOutputScaleX()+","+s.getOutputScaleY());
   Platform.exit();
  }));
 }
}
