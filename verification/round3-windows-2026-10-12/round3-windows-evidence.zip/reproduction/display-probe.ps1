Add-Type -AssemblyName System.Windows.Forms
Add-Type @'
using System;
using System.Runtime.InteropServices;
public class DisplayProbe {
 [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
 public struct DEVMODE {
  [MarshalAs(UnmanagedType.ByValTStr,SizeConst=32)] public string name;
  public ushort spec, driver, size, extra; public uint fields;
  public int x,y; public uint orientation,fixedOutput;
  public short color,duplex,yResolution,ttOption,collate;
  [MarshalAs(UnmanagedType.ByValTStr,SizeConst=32)] public string form;
  public ushort logPixels; public uint bits,width,height,flags,frequency;
  public uint icmMethod,icmIntent,mediaType,ditherType,reserved1,reserved2,panningWidth,panningHeight;
 }
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern bool EnumDisplaySettings(string name,int index,ref DEVMODE mode);
 [DllImport("user32.dll")] public static extern uint GetDpiForSystem();
 [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr value);
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr value);
 [DllImport("user32.dll")] public static extern IntPtr OpenInputDesktop(uint flags,bool inherit,uint access);
 [DllImport("user32.dll")] public static extern bool CloseDesktop(IntPtr value);
}
'@
[DisplayProbe]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null
[DisplayProbe]::SetThreadDpiAwarenessContext([IntPtr](-4)) | Out-Null
$inputDesktop = [DisplayProbe]::OpenInputDesktop(0,$false,1)
$result = [ordered]@{ interactive=[Environment]::UserInteractive; inputDesktopAvailable=($inputDesktop -ne [IntPtr]::Zero); systemDpi=[DisplayProbe]::GetDpiForSystem(); screens=@() }
if ($inputDesktop -ne [IntPtr]::Zero) { [DisplayProbe]::CloseDesktop($inputDesktop) | Out-Null }
foreach ($screen in [System.Windows.Forms.Screen]::AllScreens) {
 $m = New-Object DisplayProbe+DEVMODE
 $m.size = [Runtime.InteropServices.Marshal]::SizeOf($m)
 [DisplayProbe]::EnumDisplaySettings($screen.DeviceName,-1,[ref]$m) | Out-Null
 $currentMode=[ordered]@{width=$m.width;height=$m.height;frequency=$m.frequency;bits=$m.bits}
 $modes = @(); $i=0
 while ([DisplayProbe]::EnumDisplaySettings($screen.DeviceName,$i,[ref]$m)) {
  $modes += "$($m.width)x$($m.height)@$($m.frequency)"; $i++
 }
 $result.screens += [ordered]@{ device=$screen.DeviceName; primary=$screen.Primary; bounds=$screen.Bounds.ToString(); workArea=$screen.WorkingArea.ToString(); currentMode=$currentMode; modes=@($modes | Sort-Object -Unique) }
}
$result | ConvertTo-Json -Depth 8 | Tee-Object -FilePath "$PSScriptRoot/display-probe.json"
