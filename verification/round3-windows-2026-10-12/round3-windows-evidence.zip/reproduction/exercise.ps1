param([string]$Prefix,[double]$Scale=1,[int]$WideHeight=450)
. "$PSScriptRoot/ui.ps1"
$p=Get-AppWindow PonHub; $r=New-Object NativeUi+RECT
[NativeUi]::GetWindowRect($p.MainWindowHandle,[ref]$r)|Out-Null
$left=$r.left; $top=$r.top
function Cmd([string]$text) { Click-Point ($left+150*$Scale) ($top+90*$Scale); Send-AppKeys PonHub "^a$text{ENTER}" }
function Shot([string]$suffix) { Save-Window PonHub "$Prefix-$suffix.png" | Out-Null }
function Wheel([int]$delta,[int]$count=1,[bool]$result=$false) { $y=265; if($result){$y=155}; Wheel-Point ($left+220*$Scale) ($top+$y*$Scale) $delta $count }
Cmd 'list r/parent'; Shot 'parent-count'
Cmd 'list r/student'; Shot 'student-count'
Click-Point ($left+160*$Scale) ($top+250*$Scale)
Send-AppKeys PonHub '{HOME}{DOWN}'
Click-Point ($left+150*$Scale) ($top+90*$Scale)
Send-AppKeys PonHub '^aadd r/student n/Unfinished'
Send-AppKeys PonHub '{F1}'; Shot 'f1-command-draft'
Click-Point ($left+150*$Scale) ($top+155*$Scale)
Send-AppKeys PonHub '{F1}'; Shot 'f1-result-draft'
Click-Point ($left+85*$Scale) ($top+48*$Scale); Shot 'help-menu'
Click-Point ($left+100*$Scale) ($top+81*$Scale); Shot 'help-menu-result'
Drag-Point ($left+448*$Scale) ($top+358*$Scale) ($left+598*$Scale) ($top+($WideHeight-2)*$Scale); Shot 'drag-wide'
Drag-Point ($left+598*$Scale) ($top+($WideHeight-2)*$Scale) ($left+448*$Scale) ($top+358*$Scale); Shot 'drag-narrow'
Cmd 'help add'; Wheel -1200 5 $true; Shot 'help-final-after-resize'
Cmd 'list r/tutor'; Wheel 1200 30
for($i=0;$i -lt 12;$i++) {Wheel -120 2; Shot "tutor-scroll-$i"}
Cmd 'list'; Wheel -1200 30; Shot 'final-person-bottom-after-resize'; Wheel 120 2; Shot 'final-person-heading'
Cmd 'list r/student'; Wheel 1200 30
for($i=0;$i -lt 4;$i++){Wheel -120 1; Shot "optional-$i"}
Cmd 'list r/all'; Shot 'invalid-role'
Click-Point ($left+37*$Scale) ($top+48*$Scale); Shot 'file-exit-menu'
Click-Point ($left+45*$Scale) ($top+81*$Scale)
Start-Sleep -Milliseconds 700
if(Get-Process -Id $p.Id -ErrorAction SilentlyContinue){throw 'File Exit did not end process'}
Copy-Item "$PSScriptRoot/run/preferences.json" "$PSScriptRoot/$Prefix-retained-preferences.json"
Copy-Item "$PSScriptRoot/run/stderr.txt" "$PSScriptRoot/$Prefix-interactions.log"
Start-PonHub; Shot 'restart'
Get-FileHash "$PSScriptRoot/run/data/ponhub.json" | ConvertTo-Json | Set-Content "$PSScriptRoot/$Prefix-after-hash.json"
