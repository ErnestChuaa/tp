$ErrorActionPreference='Stop'
$base=Split-Path $PSScriptRoot -Parent
. "$base/ui.ps1"
$screen=[Windows.Forms.Screen]::PrimaryScreen.Bounds
if($screen.Width -ne 1280 -or $screen.Height -ne 720) { throw "Exact test requires actual 1280x720; observed $($screen.Width)x$($screen.Height). No acceptance run started." }
$metrics=& 'C:/Program Files/Java/jdk-25.0.4/bin/java.exe' -cp "$base/run/ponhub.jar" "$base/ScreenMetrics.java" 2> "$PSScriptRoot/after-login-javafx-stderr.txt"
$metrics | Set-Content "$PSScriptRoot/after-login-javafx-metrics.txt"
if($metrics -notmatch 'outputScale=1\.5,1\.5') { throw "Exact test requires active JavaFX scale 1.5; observed $metrics. Custom scaling may still need Windows sign-out/sign-in. No acceptance run started." }
$jarHash=(Get-FileHash "$base/run/ponhub.jar").Hash
if($jarHash -ne 'EF7439586EFCED26861A6E9CDD170A92EB076C2DA792FF8BDA54944014CC1DCE'){throw 'Unexpected JAR: artifact identity changed'}
$fixtureHash=(Get-FileHash "$base/run/data/ponhub.json").Hash
if($fixtureHash -ne 'F9E57F588AAA738503792AB9ED88317C729A032EE618C983005FEA87CB1574F3'){throw 'Unexpected synthetic fixture: identity changed'}
Start-Process ms-settings:taskbar
Start-Sleep -Seconds 1
$n=Find-Setting SystemSettings_Taskbar_Autohide_CheckBox
$toggle=$n.GetCurrentPattern([Windows.Automation.TogglePattern]::Pattern)
if($toggle.Current.ToggleState -eq 'On'){$toggle.Toggle()}
Start-Process ms-settings:display
Start-Sleep -Seconds 1
(Find-Setting ItemsControlScrollViewer).GetCurrentPattern([Windows.Automation.ScrollPattern]::Pattern).SetScrollPercent(-1,25)
Start-Sleep -Milliseconds 300
Save-SettingsEvidence '720-150-settings.png'
& "$base/display-probe.ps1" | Out-Null
Copy-Item "$base/display-probe.json" "$base/720-150-display-metrics.json"
& 'C:/Program Files/Java/jdk-25.0.4/bin/java.exe' -cp "$base/run/ponhub.jar" "$base/ScreenMetrics.java" 2> "$base/720-150-javafx-stderr.txt" | Set-Content "$base/720-150-javafx-metrics.txt"
@{guiSettings=@{windowWidth=450;windowHeight=360;windowCoordinates=@{x=50;y=50}}} | ConvertTo-Json -Depth 4 | Set-Content "$base/run/preferences.json"
Start-PonHub
$p=Get-AppWindow PonHub
if([NativeUi]::GetDpiForWindow($p.MainWindowHandle) -ne 144){Exit-PonHub;throw 'Native application DPI is not 144; exact test aborted'}
Save-Window PonHub '720-150-launch.png'
& "$base/exercise.ps1" -Prefix '720-150' -Scale 1.5 -WideHeight 380
& "$base/recover.ps1" -Prefix '720-150'
$afterHash=(Get-FileHash "$base/run/data/ponhub.json").Hash
if($afterHash -ne $fixtureHash){throw 'Operational fixture bytes changed'}
"Exact native 720p/150% action sequences completed. Inspect screenshot results and logs before recording PASS. Restore original Windows scaling/resolution/taskbar after verification." | Set-Content "$PSScriptRoot/exact-run-result.txt"
